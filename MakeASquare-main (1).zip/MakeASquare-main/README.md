# Project 5: Make a square
Make a square with size 4X4 by using 4 or 5 pieces. The pieces can be rotated or flipped and all pieces should be used to form a square.

## OS2 Project 5
![Make a square OS2 Project](https://github.com/KhaledAdelM/MakeASquare/blob/main/OS2%20Project.jpg)

## Code
[Make a square sec](/MakeASquare)

## Documentation
[Make a square documentation](/MakeASquare%20(DocumentatACion).pdf)

## Video
[Make a square Video](/MakeASquare%20(Video).mp4)


